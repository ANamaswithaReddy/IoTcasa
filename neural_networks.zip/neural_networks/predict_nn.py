from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from tflite_runtime.interpreter import Interpreter
import uvicorn

# Load the scaler (if you want to keep preprocessing in the API)
scaler_X = joblib.load('scaler.joblib')

# Load the TFLite model and prepare the interpreter
interpreter = Interpreter(model_path="smart_home_nn_model.tflite")
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

class Features(BaseModel):
    Hour_of_Day: int       # 0–23
    Temperature: float     # e.g., 28.5
    Occupancy: int         # 0 or 1
    Humidity: int          # e.g., 65

output_labels = [
    'AC1_Status', 'AC1_Temp_Setting', 'AC1_Fan_Speed',
    'AC2_Status', 'AC2_Fan_Speed', 'AC2_Temp_Setting',
    'Fan1_Status', 'Fan1_Speed', 'Fan2_Status', 'Fan2_Speed'
]

app = FastAPI()

def validate_input(data: dict):
    if not (0 <= data['Hour_of_Day'] <= 23):
        raise ValueError("Hour_of_Day must be in 0–23")
    if not (-18 <= data['Temperature'] <= 40):
        raise ValueError("Temperature must be between -18°C and 40°C")
    if data['Occupancy'] not in [0, 1]:
        raise ValueError("Occupancy must be 0 or 1")
    if not (0 <= data['Humidity'] <= 100):
        raise ValueError("Humidity must be in 0–100")

@app.post("/predict")
async def predict(data: Features):
    try:
        # Step 1: Convert and validate input
        input_dict = data.dict()
        validate_input(input_dict)

        # Step 2: Scale input
        x_input = np.array([
            input_dict['Hour_of_Day'],
            input_dict['Temperature'],
            input_dict['Occupancy'],
            input_dict['Humidity']
        ], dtype=np.float32).reshape(1, -1)
        x_scaled = scaler_X.transform(x_input)

        # Step 3: Inference
        interpreter.set_tensor(input_details[0]['index'], x_scaled)
        interpreter.invoke()
        y_pred = interpreter.get_tensor(output_details[0]['index'])[0]

        # Step 4: Postprocess
        y_pred = np.round(y_pred).astype(int)
        result = {
            'AC1_Status': int(np.clip(y_pred[0], 0, 1)),
            'AC1_Temp_Setting': int(np.clip(y_pred[1], 16, 38)),
            'AC1_Fan_Speed': int(np.clip(y_pred[2], 1, 5)),
            'AC2_Status': int(np.clip(y_pred[3], 0, 1)),
            'AC2_Fan_Speed': int(np.clip(y_pred[4], 1, 5)),
            'AC2_Temp_Setting': int(np.clip(y_pred[5], 16, 38)),
            'Fan1_Status': int(np.clip(y_pred[6], 0, 1)),
            'Fan1_Speed': int(np.clip(y_pred[7], 1, 5)),
            'Fan2_Status': int(np.clip(y_pred[8], 0, 1)),
            'Fan2_Speed': int(np.clip(y_pred[9], 1, 5)),
        }

        return result

    except ValueError as ve:
        return {"error": str(ve)}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}

if __name__ == "__main__":
    uvicorn.run("predict_nn:app", host="0.0.0.0", port=5000)
